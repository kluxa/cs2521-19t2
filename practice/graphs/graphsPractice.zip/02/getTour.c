
#include <stdio.h>
#include <stdlib.h>

#include "Graph.h"

Vertex *getTour(Graph g, int *tourLength) {
	*tourLength = 0;
	
	// TODO
	
	return NULL;
}

