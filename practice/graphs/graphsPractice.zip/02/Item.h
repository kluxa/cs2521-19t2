
#ifndef ITEM_H
#define ITEM_H

typedef int Item;

#define ITEM_DUMP(file, item) fprintf(file, "%d", item)

#endif

