
#include <stdbool.h>

#include "Graph.h"

bool verifyHamiltonPath(Graph g, Vertex *path, int pathLength) {
	// TODO
	return false;
}

