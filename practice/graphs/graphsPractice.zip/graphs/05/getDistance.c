
#include <stdio.h>
#include <stdlib.h>

#include "Graph.h"
#include "Queue.h"

int getDistance(Graph g, Vertex src, Vertex dest) {
	return -1;
}

