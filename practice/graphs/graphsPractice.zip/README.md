# Graphs Practice Questions

- Each question is in its own directory (`01`, `02`, etc.).
- The instructions for each question are in a `question.txt` file.
- The solutions for each question are in a `solution/` directory. Don't look at the solutions until you've had a go at doing the question! Spent at least an hour on each question before giving up.
- Let me know if you encounter any bugs in the solutions.
- Have fun!
