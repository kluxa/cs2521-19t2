
#ifndef ITEM_H
#define ITEM_H

typedef void * Item;

#define ITEM_DUMP(file, item) fprintf(file, "%p", item)

#endif

