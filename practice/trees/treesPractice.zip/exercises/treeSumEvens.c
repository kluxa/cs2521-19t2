
#include <stdlib.h>

#include "tree.h"

/**
 * Returns the sum of all of the even values in the tree.
 */
int treeSumEvens(Tree t) {
	return 0;
}

