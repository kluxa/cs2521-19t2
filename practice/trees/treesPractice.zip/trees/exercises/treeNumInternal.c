
#include <stdlib.h>

#include "tree.h"

/**
 * Returns  the  number of internal nodes in the given tree. An internal
 * node is a node that has one or more children, i.e., is not a leaf.
 */
int treeNumInternal(Tree t) {
	return 0;
}

