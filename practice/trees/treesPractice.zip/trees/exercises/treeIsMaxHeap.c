
#include <stdlib.h>

#include "tree.h"

/**
 * Returns  true  if  the given tree is a max heap, and false otherwise.
 * Assumes that the given tree is complete.
 */
bool treeIsMaxHeap(Tree t) {
	return false;
}

