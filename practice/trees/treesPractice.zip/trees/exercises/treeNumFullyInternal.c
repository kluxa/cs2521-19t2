
#include <stdlib.h>

#include "tree.h"

/**
 * Returns the number of fully internal nodes in the given tree. A fully
 * internal node is a node that has two children.
 */
int treeNumFullyInternal(Tree t) {
	return 0;
}

