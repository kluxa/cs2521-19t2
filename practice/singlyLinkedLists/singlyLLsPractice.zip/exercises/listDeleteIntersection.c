
#include <stdio.h>
#include <stdlib.h>

#include "list.h"

/**
 * Deletes all values that occur in both lists from both lists.
 */
void listDeleteIntersection(List l1, List l2) {
	(void) l1;
	(void) l2;
}

