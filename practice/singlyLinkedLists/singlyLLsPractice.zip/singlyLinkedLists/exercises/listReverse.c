
#include <stdio.h>
#include <stdlib.h>

#include "list.h"

/**
 * Reverses the given list.
 */
void listReverse(List l) {
	// TODO
}

