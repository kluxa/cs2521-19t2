
#include <stdio.h>
#include <stdlib.h>

#include "list.h"

/**
 * Returns the k'th last element in the list. You can assume that k will
 * be between 1 and N where N is the length of the list.  You can assume
 * that the list contains at least one element (i.e., it is not empty).
 */
int listKthLast(List l, int k) {
	// TODO
	return 0;
}

