
#include <stdio.h>
#include <stdlib.h>

#include "list.h"

/**
 * Returns  true if the list is in ascending order, and false otherwise.
 * For  example, 2 -> 3 -> 3 -> 5 -> X is ascending, 2 -> 5 -> 3 -> X is
 * not. An empty list is considered to be ascending.
 */
bool listIsAscending(List l) {
	// TODO
	return false;
}

