
#include <stdio.h>
#include <stdlib.h>

#include "list.h"

/**
 * Returns  true  if the given list is palindromic, and false otherwise.
 * An empty list is considered to be palindromic.
 * Hint: use listKthLast
 */
bool listIsPalindromic(List l) {
	// TODO
	return false;
}

