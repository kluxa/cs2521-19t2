// getPeaks.h - testing DLList data type
// Written by Ashesh Mahidadia, August 2017


DLList getPeaks(DLList L);


